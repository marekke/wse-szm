package io.pw.data;

/**
 * Created by pwykowski
 */
public interface Transformer<T> {

	T transform();

}
