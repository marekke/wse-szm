package io.pw.exception;

public class ProductQtyException extends RuntimeException {
    public ProductQtyException(String message) {
        super(message);
    }
}
